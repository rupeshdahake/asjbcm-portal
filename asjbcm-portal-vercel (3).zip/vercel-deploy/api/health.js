/**
 * Vercel Serverless Function: /api/health
 */

export default async function handler(req, res) {
  return res.status(200).json({
    status: 'ok',
    aiReady: true,
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    platform: 'vercel'
  });
}
