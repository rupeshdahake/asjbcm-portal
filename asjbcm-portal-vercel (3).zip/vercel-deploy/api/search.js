/**
 * Vercel Serverless Function: /api/search
 * Web search — calls ZAI API directly with fetch (no SDK dependency)
 */

const ZAI_CONFIG = {
  baseUrl: "https://internal-api.z.ai/v1",
  apiKey: "Z.ai",
  chatId: "chat-66ac7001-69a9-4e55-b491-e145c98384db",
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNGY3NWYxYzEtMjRlMy00ZDE3LWFjOTgtZTZjNjNjYTRhYjI3IiwiY2hhdF9pZCI6ImNoYXQtNjZhYzcwMDEtNjlhOS00ZTU1LWI0OTEtZTE0NWM5ODM4NGRiIiwicGxhdGZvcm0iOiJ6YWkifQ.qJgQLbR1MMfpOS5SZ-6h3HWFe6pmZPp0qazVm0KAnYw",
  userId: "4f75f1c1-24e3-4d17-ac98-e6c63ca4ab27"
};

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { query, num = 10, recency_days } = req.body;

    if (!query || typeof query !== 'string') {
      return res.status(400).json({ error: 'Search query is required' });
    }

    // Call ZAI web_search function directly
    const searchArgs = {
      query: query,
      num: Math.min(num, 20)
    };
    if (recency_days) {
      searchArgs.recency_days = recency_days;
    }

    const response = await fetch(`${ZAI_CONFIG.baseUrl}/functions/web_search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${ZAI_CONFIG.apiKey}`,
        'X-Z-AI-From': 'Z',
        'X-Chat-Id': ZAI_CONFIG.chatId,
        'X-User-Id': ZAI_CONFIG.userId,
        'X-Token': ZAI_CONFIG.token
      },
      body: JSON.stringify(searchArgs)
    });

    if (!response.ok) {
      console.error('ZAI search error:', response.status);
      return res.status(500).json({ error: 'Search service error' });
    }

    const results = await response.json();

    if (!Array.isArray(results)) {
      return res.status(200).json({ results: [], summary: 'No results found.' });
    }

    const formatted = results.map((item, index) => ({
      position: index + 1,
      title: item.name || 'Untitled',
      url: item.url || '',
      description: item.snippet || '',
      domain: item.host_name || '',
      date: item.date || ''
    }));

    // Generate AI summary
    let summary = '';
    try {
      const searchContext = results.slice(0, 5)
        .map(r => `${r.name}: ${r.snippet}`)
        .join('\n');

      const summaryResponse = await fetch(`${ZAI_CONFIG.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${ZAI_CONFIG.apiKey}`,
          'X-Z-AI-From': 'Z',
          'X-Chat-Id': ZAI_CONFIG.chatId,
          'X-User-Id': ZAI_CONFIG.userId,
          'X-Token': ZAI_CONFIG.token
        },
        body: JSON.stringify({
          messages: [
            { role: 'assistant', content: 'Summarize the search results in 2-3 sentences.' },
            { role: 'user', content: `Query: "${query}"\n\nResults:\n${searchContext}` }
          ],
          thinking: { type: 'disabled' }
        })
      });

      if (summaryResponse.ok) {
        const summaryData = await summaryResponse.json();
        summary = summaryData.choices?.[0]?.message?.content || '';
      }
    } catch (e) {
      summary = 'Summary unavailable.';
    }

    return res.status(200).json({
      query: query,
      results: formatted,
      summary: summary,
      totalResults: formatted.length,
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Search API error:', error.message);
    return res.status(500).json({
      error: 'Failed to perform web search',
      fallback: 'Search is currently unavailable.'
    });
  }
}
