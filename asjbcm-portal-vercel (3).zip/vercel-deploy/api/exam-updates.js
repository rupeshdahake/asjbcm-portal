/**
 * Vercel Serverless Function: /api/exam-updates
 * Fetches latest govt vacancies — calls ZAI API directly with fetch
 */

const ZAI_CONFIG = {
  baseUrl: "https://internal-api.z.ai/v1",
  apiKey: "Z.ai",
  chatId: "chat-66ac7001-69a9-4e55-b491-e145c98384db",
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNGY3NWYxYzEtMjRlMy00ZDE3LWFjOTgtZTZjNjNjYTRhYjI3IiwiY2hhdF9pZCI6ImNoYXQtNjZhYzcwMDEtNjlhOS00ZTU1LWI0OTEtZTE0NWM5ODM4NGRiIiwicGxhdGZvcm0iOiJ6YWkifQ.qJgQLbR1MMfpOS5SZ-6h3HWFe6pmZPp0qazVm0KAnYw",
  userId: "4f75f1c1-24e3-4d17-ac98-e6c63ca4ab27"
};

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    return res.status(200).end();
  }

  try {
    const queries = [
      'latest government job vacancies 2026 India',
      'upcoming competitive exams 2026 India notification',
      'SSC IBPS MPSC exam 2026 notification'
    ];

    const allResults = [];
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${ZAI_CONFIG.apiKey}`,
      'X-Z-AI-From': 'Z',
      'X-Chat-Id': ZAI_CONFIG.chatId,
      'X-User-Id': ZAI_CONFIG.userId,
      'X-Token': ZAI_CONFIG.token
    };

    for (const q of queries) {
      try {
        const response = await fetch(`${ZAI_CONFIG.baseUrl}/functions/web_search`, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ query: q, num: 5, recency_days: 30 })
        });

        if (response.ok) {
          const results = await response.json();
          if (Array.isArray(results)) {
            results.forEach(r => allResults.push({
              title: r.name, url: r.url, description: r.snippet,
              source: r.host_name, date: r.date
            }));
          }
        }
      } catch (e) {}
    }

    const seen = new Set();
    const unique = allResults.filter(r => {
      if (seen.has(r.url)) return false;
      seen.add(r.url);
      return true;
    });

    return res.status(200).json({
      updates: unique.slice(0, 15),
      fetchedAt: new Date().toISOString()
    });

  } catch (error) {
    console.error('Exam updates error:', error.message);
    return res.status(500).json({ error: 'Failed to fetch exam updates' });
  }
}
