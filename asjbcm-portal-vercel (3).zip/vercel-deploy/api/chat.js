/**
 * Vercel Serverless Function: /api/chat
 * AI Chatbot — calls ZAI API directly with fetch (no SDK dependency)
 */

const ZAI_CONFIG = {
  baseUrl: "https://internal-api.z.ai/v1",
  apiKey: "Z.ai",
  chatId: "chat-66ac7001-69a9-4e55-b491-e145c98384db",
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNGY3NWYxYzEtMjRlMy00ZDE3LWFjOTgtZTZjNjNjYTRhYjI3IiwiY2hhdF9pZCI6ImNoYXQtNjZhYzcwMDEtNjlhOS00ZTU1LWI0OTEtZTE0NWM5ODM4NGRiIiwicGxhdGZvcm0iOiJ6YWkifQ.qJgQLbR1MMfpOS5SZ-6h3HWFe6pmZPp0qazVm0KAnYw",
  userId: "4f75f1c1-24e3-4d17-ac98-e6c63ca4ab27"
};

const SYSTEM_PROMPT = `You are "ASJBCM Exam Guide", an AI assistant for the ASJBCM Competitive Exam Preparation Portal.

Your role is to help students with:
1. EXAM GUIDANCE: Advise on which competitive exams to target (UPSC, MPSC, SSC, Banking, Railway, Defence, Teaching, etc.)
2. STUDY TIPS: Preparation strategies, time management, subject-wise tips, book recommendations
3. SYLLABUS QUERIES: Exam patterns, syllabus topics, marking schemes
4. CAREER COUNSELLING: Help choose between career paths
5. DOUBT SOLVING: Answer academic questions on History, Geography, Polity, Economy, Science, Math, Reasoning, English
6. MOTIVATION: Encourage students, share success strategies

IMPORTANT RULES:
- Always be supportive, encouraging, and professional
- Give practical, actionable advice
- Keep responses concise (max 3-4 paragraphs)
- Respond in the same language the student uses (English, Hindi, or Marathi)`;

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, history = [] } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Build conversation messages
    const messages = [
      { role: 'assistant', content: SYSTEM_PROMPT },
      ...history.slice(-8).map(h => ({
        role: h.role || 'user',
        content: h.content || ''
      })),
      { role: 'user', content: message }
    ];

    // Call ZAI API directly with fetch
    const response = await fetch(`${ZAI_CONFIG.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${ZAI_CONFIG.apiKey}`,
        'X-Z-AI-From': 'Z',
        'X-Chat-Id': ZAI_CONFIG.chatId,
        'X-User-Id': ZAI_CONFIG.userId,
        'X-Token': ZAI_CONFIG.token
      },
      body: JSON.stringify({
        messages: messages,
        thinking: { type: 'disabled' }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('ZAI API error:', response.status, errorText);
      return res.status(500).json({
        error: 'AI service error',
        fallback: 'I am having trouble responding right now. Please try again later.'
      });
    }

    const data = await response.json();
    const aiResponse = data.choices?.[0]?.message?.content;

    if (!aiResponse || aiResponse.trim().length === 0) {
      return res.status(200).json({
        response: 'I apologize, but I could not generate a response. Please try rephrasing your question.',
        source: 'ai'
      });
    }

    return res.status(200).json({
      response: aiResponse,
      source: 'ai',
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Chat API error:', error.message);
    return res.status(500).json({
      error: 'Failed to process chat request',
      fallback: 'I am having trouble responding right now. Please try again in a moment.'
    });
  }
}
